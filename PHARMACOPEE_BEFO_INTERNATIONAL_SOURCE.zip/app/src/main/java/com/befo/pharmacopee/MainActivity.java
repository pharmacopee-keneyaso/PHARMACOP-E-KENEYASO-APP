package com.befo.pharmacopee;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  w.getSettings().setJavaScriptEnabled(true);
  w.getSettings().setDomStorageEnabled(true);
  w.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView v,String u){
    if(u.startsWith("https://wa.me/")||u.startsWith("tel:")){
     startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); return true;
    }
    return false;
   }
  });
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
}