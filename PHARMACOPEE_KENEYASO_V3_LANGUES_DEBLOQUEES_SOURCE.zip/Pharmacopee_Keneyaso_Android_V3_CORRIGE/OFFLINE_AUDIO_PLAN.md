# PLAN AUDIO HORS CONNEXION — PHARMACOPÉE KENEYASO

Objectif validé :
1. Produits, photos, textes, profil et paramètres restent consultables hors connexion.
2. Les ÉMISSIONS et Dédicaces peuvent être parcourues en ligne.
3. Chaque audio dispose d’un bouton « Télécharger ».
4. Après téléchargement, l’audio est stocké localement dans l’application.
5. Le lecteur utilise le fichier local quand Internet est absent.
6. L’utilisateur peut supprimer un téléchargement pour libérer la mémoire.
7. Une nouvelle émission/dédicace publiée par l’Admin apparaît après synchronisation Internet.

Implémentation Android recommandée :
- Catalogue de métadonnées : API/backend en ligne.
- Fichiers audio : stockage objet/CDN avec URL sécurisée.
- Téléchargements : DownloadManager ou WorkManager.
- État local : petite base Room/SQLite (audio_id, chemin local, taille, date, statut).
- Lecteur : Media3 / ExoPlayer pour lecture locale et distante.
- Synchronisation : au démarrage et au retour d’Internet.
- Aucune obligation de réinstaller l’application pour publier un nouvel audio.

IMPORTANT :
La version HTML incluse dans ce projet est la version de contrôle validée. La partie « téléchargement audio hors connexion + synchronisation Admin en ligne » est l’étape native suivante à développer et tester avant publication.
