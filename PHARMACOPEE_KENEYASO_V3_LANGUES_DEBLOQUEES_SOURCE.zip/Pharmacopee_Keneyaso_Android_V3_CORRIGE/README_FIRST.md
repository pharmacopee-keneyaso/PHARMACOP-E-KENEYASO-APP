# PHARMACOPÉE KENEYASO — ANDROID V1.0

Ce dossier est la base de développement Android préparée à partir de la version fonctionnelle validée.

## Ce qui est déjà inclus
- Interface validée dans `app/src/main/assets/index.html`
- Nom de l’application : Pharmacopée Keneyaso
- Identifiant proposé : `com.pharmacopee.keneyaso`
- targetSdk / compileSdk : 36
- WebView Android native
- Ouverture des liens externes WhatsApp / Facebook / YouTube / téléphone
- Sélection de fichiers depuis les formulaires Admin
- Icône générée à partir du logo officiel
- Fiche Play Store FR/AR
- Politique de confidentialité
- Checklist de publication
- Plan technique pour audio hors connexion

## Pour construire l’application
1. Installer Android Studio récent compatible avec AGP 8.13.x.
2. Installer Android SDK Platform 36 et Build Tools requis.
3. Ouvrir ce dossier dans Android Studio.
4. Laisser Gradle synchroniser le projet.
5. Tester `app` sur un téléphone Android.
6. Avant la première publication, confirmer définitivement l’identifiant `com.pharmacopee.keneyaso`.
7. Créer une clé de signature et la conserver en lieu sûr.
8. Android Studio → Build / Generate Signed App Bundle or APK → Android App Bundle.
9. Générer le fichier `.aab`.

## Important
Ce dossier n’est pas encore un fichier `.aab` signé : il faut le construire dans Android Studio après installation du SDK Android et tester l’application sur un appareil réel.
