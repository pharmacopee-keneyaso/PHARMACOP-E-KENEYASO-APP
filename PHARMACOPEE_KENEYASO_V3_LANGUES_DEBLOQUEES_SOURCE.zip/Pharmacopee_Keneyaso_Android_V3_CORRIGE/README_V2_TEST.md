# PHARMACOPÉE KENEYASO — V2 TEST

Cette V2 conserve la V1 et ajoute les corrections validées :
- écran de bienvenue + choix Français / العربية ;
- recherche Produits instantanée ;
- lecteur audio ÉMISSIONS FAÏDA et Dédicaces ;
- lecture/pause, -10s, +10s, progression, durée ;
- enregistrer hors connexion et partager ;
- Admin ÉMISSIONS / Dédicaces : Ajouter, Modifier, Supprimer pour les ajouts locaux ;
- Mode d’utilisation protégé par le code privé existant.

## Important pour ce TEST
Le lecteur Android recherche les fichiers audio originaux déjà présents sur le téléphone par leur nom exact.
232 éléments de la liste ont été reliés automatiquement à un fichier audio original disponible dans les fichiers de travail.
Les quelques titres sans fichier correspondant restent signalés comme indisponibles.

Pour la version Play Store destinée à tous les utilisateurs, les audios devront ensuite être publiés sur un stockage en ligne afin que le bouton Télécharger puisse récupérer un fichier qui n'est pas déjà présent sur le téléphone.
