# CHECKLIST GOOGLE PLAY — VERSION 1.0

## Technique
- [x] Nom : Pharmacopée Keneyaso
- [x] Version : 1.0
- [x] Identifiant proposé : com.pharmacopee.keneyaso
- [x] compileSdk 36
- [x] targetSdk 36
- [x] Android App Bundle prévu pour Google Play
- [ ] Ouvrir le projet dans Android Studio
- [ ] Installer Android SDK 36
- [ ] Générer une clé de signature sécurisée
- [ ] Générer le fichier .aab signé
- [ ] Tester sur plusieurs téléphones Android

## Contenu
- [x] Accueil validé
- [x] Produits validés
- [x] ÉMISSIONS validées
- [x] Dédicaces validées
- [x] Profil validé
- [x] WhatsApp public et privé configurés
- [x] Mode d’utilisation vendeurs prévu comme espace privé
- [x] Espace Admin prévu

## Santé / conformité
- [x] Avertissement santé préparé
- [x] Politique de confidentialité préparée
- [ ] Publier la politique de confidentialité sur une URL publique
- [ ] Remplir la déclaration Health apps dans Play Console
- [ ] Vérifier toutes les descriptions produits et supprimer toute promesse médicale absolue
- [ ] Compléter la section Data safety selon la version réellement publiée

## Compte Google Play
- [ ] Créer / vérifier le compte Play Console
- [ ] Vérifier l’identité du développeur
- [ ] Si le compte personnel est soumis aux nouvelles règles : préparer le test fermé requis
- [ ] Ajouter les testeurs
- [ ] Tester pendant la durée requise
- [ ] Demander l’accès à la production
