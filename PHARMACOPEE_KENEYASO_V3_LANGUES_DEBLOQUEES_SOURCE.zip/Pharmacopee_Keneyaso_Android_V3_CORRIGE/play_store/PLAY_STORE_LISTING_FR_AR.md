# FICHE GOOGLE PLAY — PHARMACOPÉE KENEYASO

## Nom de l’application
Pharmacopée Keneyaso

## Version
1.0

## Identifiant Android proposé
com.pharmacopee.keneyaso

IMPORTANT : cet identifiant doit être confirmé avant la toute première publication Google Play. Une fois l’application publiée, il ne faut plus le changer.

## Description courte FR
Catalogue Keneyaso, produits validés, émissions et dédicaces audio.

## Description courte AR
كتالوج كينيازو للمنتجات المعتمدة والحلقات والإهداءات الصوتية.

## Description complète FR
Pharmacopée Keneyaso rassemble dans une seule application le catalogue des produits validés, les ÉMISSIONS, les chansons dédicaces, le profil officiel et les contacts.

• Catalogue avec photos réelles des kits validés
• Présentation français + arabe
• Commande et contact WhatsApp
• ÉMISSIONS et contenus audio
• Chansons dédicaces
• Profil officiel et liens Facebook / YouTube
• Espace vendeurs et espace administrateur réservés
• Préparation de l’écoute audio hors connexion après téléchargement

AVERTISSEMENT SANTÉ :
Cette application présente des informations sur des produits et pratiques de médecine traditionnelle. Elle n’est pas un dispositif médical et ne diagnostique, ne traite, ne guérit ni ne prévient une maladie. Pour toute question médicale, consultez un professionnel de santé qualifié.

This app is not a medical device and does not diagnose, treat, cure, or prevent any medical condition.

## Description complète AR
يضم تطبيق فارماكوبيا كينيازو كتالوج المنتجات المعتمدة والحلقات الصوتية وأغاني الإهداء والملف الرسمي ووسائل الاتصال.

• صور حقيقية للمجموعات المعتمدة
• محتوى بالفرنسية والعربية
• التواصل والطلب عبر واتساب
• الحلقات والمحتوى الصوتي
• أغاني الإهداء
• الملف الرسمي وروابط فيسبوك ويوتيوب
• مساحة خاصة للبائعين والإدارة
• الاستماع دون اتصال بعد تنزيل الملفات الصوتية

تنبيه صحي:
يقدم التطبيق معلومات حول منتجات وممارسات الطب التقليدي، ولا يُعد جهازاً طبياً ولا يشخّص أو يعالج أو يشفي أو يمنع أي حالة مرضية. عند وجود مشكلة صحية، يُرجى استشارة مختص صحي مؤهل.

## Contacts publics
+224 620 22 22 58
+224 611 49 44 47
+224 660 18 18 61

## Contact du profil
Dr Aboubacar Béfo Keita
+224 628 11 00 41
