plugins {
    id("com.android.application")
}

android {
    namespace = "com.pharmacopee.keneyaso"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pharmacopee.keneyaso"
        minSdk = 24
        targetSdk = 36
        versionCode = 3
        versionName = "3.0-corrige"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
