# Version 1.0 — aucune règle ProGuard spéciale pour le moment.
