package com.pharmacopee.keneyaso;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.Normalizer;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int AUDIO_PERMISSION_REQUEST = 2002;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String pendingFile = null;
    private String currentFile = null;
    private Uri currentUri = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AudioBridge(), "AndroidAudio");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return openExternalIfNeeded(request.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return openExternalIfNeeded(Uri.parse(url)); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { filePathCallback = null; return false; }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean openExternalIfNeeded(Uri uri) {
        String scheme = uri.getScheme(); if (scheme == null) return false;
        if (scheme.equalsIgnoreCase("file") || scheme.equalsIgnoreCase("about") || scheme.equalsIgnoreCase("data")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; } catch (Exception e) { return false; }
    }

    private boolean hasAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= 23) return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return true;
    }
    private void requestAudioPermission(String file) {
        pendingFile = file;
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, AUDIO_PERMISSION_REQUEST);
        else if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, AUDIO_PERMISSION_REQUEST);
    }
    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == AUDIO_PERMISSION_REQUEST) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingFile != null) {
                String f = pendingFile; pendingFile = null; playByName(f);
            } else { js("nativeErrorV2(" + JSONObject.quote("Autorisez l’accès Musique et audio pour lire vos fichiers.") + ")"); }
        }
    }

    private String normalizeAudioName(String value) {
        if (value == null) return "";
        try { value = URLDecoder.decode(value, StandardCharsets.UTF_8.name()); } catch (Exception ignored) {}
        String n = Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        n = n.toLowerCase().replace('_', ' ').replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
        return n;
    }

    private Uri findAudio(String displayName) {
        ContentResolver cr = getContentResolver();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME};
        try (Cursor c = cr.query(collection, projection, MediaStore.Audio.Media.DISPLAY_NAME + " = ?", new String[]{displayName}, MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                return ContentUris.withAppendedId(collection, id);
            }
        } catch (Exception ignored) {}
        // relaxed, case-insensitive fallback
        try (Cursor c = cr.query(collection, projection, null, null, MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
            if (c != null) while (c.moveToNext()) {
                String n = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));
                if (n != null && (n.equalsIgnoreCase(displayName) || normalizeAudioName(n).equals(normalizeAudioName(displayName)))) {
                    long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                    return ContentUris.withAppendedId(collection, id);
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private File offlineFile(String name) {
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "KeneyasoOffline");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, name.replaceAll("[\\\\/:*?\"<>|]", "_"));
    }

    private void playByName(String file) {
        runOnUiThread(() -> {
            if (!hasAudioPermission()) { requestAudioPermission(file); return; }
            try {
                releasePlayer();
                currentFile = file;
                File offline = offlineFile(file);
                player = new MediaPlayer();
                if (offline.exists() && offline.length() > 0) {
                    currentUri = Uri.fromFile(offline);
                    player.setDataSource(offline.getAbsolutePath());
                } else {
                    currentUri = findAudio(file);
                    if (currentUri == null) { js("nativeErrorV2(" + JSONObject.quote("Audio original introuvable sur ce téléphone : " + file) + ")"); releasePlayer(); return; }
                    player.setDataSource(this, currentUri);
                }
                player.setOnPreparedListener(mp -> { mp.start(); js("nativeLoadedV2(" + mp.getDuration() + ")"); startProgress(); });
                player.setOnCompletionListener(mp -> js("nativeProgressV2(" + mp.getDuration() + "," + mp.getDuration() + ",false)"));
                player.setOnErrorListener((mp, what, extra) -> { js("nativeErrorV2(" + JSONObject.quote("Erreur de lecture audio.") + ")"); return true; });
                player.prepareAsync();
            } catch (Exception e) { js("nativeErrorV2(" + JSONObject.quote("Impossible d’ouvrir cet audio original.") + ")"); }
        });
    }

    private void startProgress() {
        handler.removeCallbacksAndMessages(null);
        handler.post(new Runnable() { @Override public void run() {
            try { if (player != null) { js("nativeProgressV2("+player.getCurrentPosition()+","+player.getDuration()+","+player.isPlaying()+")"); handler.postDelayed(this,500); } } catch(Exception ignored){}
        }});
    }
    private void js(String code) {
        runOnUiThread(() -> {
            String fn = code.contains("(") ? code.substring(0, code.indexOf('(')) : code;
            webView.evaluateJavascript("if(window." + fn + "){" + code + ";}", null);
        });
    }
    private void releasePlayer() { handler.removeCallbacksAndMessages(null); if (player != null) { try { player.stop(); } catch(Exception ignored){} player.release(); player=null; } }

    public class AudioBridge {
        @JavascriptInterface public void play(String file) { playByName(file); }
        @JavascriptInterface public void toggle() { runOnUiThread(() -> { if(player==null)return; if(player.isPlaying())player.pause(); else player.start(); }); }
        @JavascriptInterface public void seekBy(int seconds) { runOnUiThread(() -> { if(player==null)return; int p=Math.max(0,Math.min(player.getDuration(),player.getCurrentPosition()+seconds*1000));player.seekTo(p); }); }
        @JavascriptInterface public void seekToPercent(int value) { runOnUiThread(() -> { if(player==null)return; int p=(int)((value/1000.0)*player.getDuration());player.seekTo(p); }); }
        @JavascriptInterface public void saveOffline(String file) { new Thread(() -> {
            try {
                if (!hasAudioPermission()) { runOnUiThread(() -> requestAudioPermission(file)); return; }
                Uri u=findAudio(file); if(u==null){js("nativeErrorV2("+JSONObject.quote("Audio introuvable sur ce téléphone.")+")");return;}
                File dest=offlineFile(file);
                try(InputStream in=getContentResolver().openInputStream(u); FileOutputStream out=new FileOutputStream(dest)) { byte[] b=new byte[65536]; int n; while((n=in.read(b))>0)out.write(b,0,n); }
                js("nativeSavedV2("+JSONObject.quote("✓ Audio enregistré hors connexion.")+")");
            } catch(Exception e){js("nativeErrorV2("+JSONObject.quote("Impossible d’enregistrer cet audio.")+")");}
        }).start(); }
        @JavascriptInterface public void share(String file) { runOnUiThread(() -> {
            if(!hasAudioPermission()){requestAudioPermission(file);return;} Uri u=findAudio(file);if(u==null){js("nativeErrorV2("+JSONObject.quote("Audio introuvable pour le partage.")+")");return;}
            Intent send=new Intent(Intent.ACTION_SEND);send.setType("audio/*");send.putExtra(Intent.EXTRA_STREAM,u);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Partager l’audio"));
        }); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] result = null; if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(result); filePathCallback = null;
        }
    }
    @Override protected void onDestroy(){releasePlayer();if(webView!=null)webView.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
