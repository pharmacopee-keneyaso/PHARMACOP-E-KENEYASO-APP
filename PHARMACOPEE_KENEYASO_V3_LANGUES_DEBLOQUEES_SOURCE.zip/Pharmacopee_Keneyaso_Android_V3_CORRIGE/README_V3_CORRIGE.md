# PHARMACOPÉE KENEYASO — V3 CORRIGÉE

Cette version corrige l’erreur de build précédente et garde le reste validé.

- écran Bienvenue affiché au démarrage ;
- choix Français / العربية ;
- recherche Produits instantanée ;
- lecteur complet ÉMISSIONS FAÏDA et Dédicaces : lecture/pause, -10 s, +10 s, progression, durée, Télécharger, Partager ;
- audio original uniquement : aucune voix synthétique / générée ;
- recherche plus robuste des fichiers audio originaux présents sur le téléphone ;
- Admin ÉMISSIONS / Dédicaces : Ajouter, Modifier, Supprimer ;
- Mode d’utilisation protégé par code ;
- WhatsApp, profil, paramètres et catalogue restent inchangés.

IMPORTANT : pour un autre utilisateur qui ne possède pas encore les fichiers audio originaux sur son téléphone, la version Play Store devra télécharger les originaux depuis un stockage en ligne.
